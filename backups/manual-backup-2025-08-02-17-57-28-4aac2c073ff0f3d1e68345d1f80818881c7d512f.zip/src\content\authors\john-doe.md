---
name: John Doe
slug: john-doe
bio: A technology enthusiast and writer
avatar: /images/authors/john-doe.jpg
social:
  twitter: johndoe
  linkedin: johndoe
  github: johndoe
---

# John Doe

Technology enthusiast and writer. 